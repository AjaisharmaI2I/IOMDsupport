//
//  MenuCollectionViewCell.swift
//  MenuHorizontalCollection
//
//  Created by Ideas2IT on 01/09/23.
//

import UIKit

class MenuCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var menuIcon: UIImageView!
    @IBOutlet weak var menuLbl: UILabel!
    
    @IBOutlet weak var lineView: UIView!
}
